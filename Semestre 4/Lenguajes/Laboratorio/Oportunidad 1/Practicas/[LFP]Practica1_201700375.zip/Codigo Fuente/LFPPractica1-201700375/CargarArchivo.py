import math
def CargarArchivo():
    print("\n")
    RutaArchivo = input(r"Ingrese la ruta del archivo .lfp que deseea cargar al programa y este le mostará los resultados: ")
    if RutaArchivo.lower().endswith(".lfp"):
        with open(RutaArchivo, "r+") as Archivo:
         for Linea in Archivo:
             LineaParaPartir = Linea

             #Prueba para ver Inicio de cada Linea
             if LineaParaPartir.startswith("IN:"):
                 # Separar la Operación Real y escribirla en el GUI:
                 OperacionReal = Linea.split(":")
                 print("Operación: ", end="")
                 print(OperacionReal[1], end="")

                 # Realizar Potencias, Factoriales y otras operaciones que no pueden ser separadas despues para facilitar el trabajo
                 # Potencias

                 # Lista que guardará la Potencia a realizar:
                 if (OperacionReal[1].find("Pow") > -1):
                     BasePotencia = ""
                     Elevado = ""
                     for i in range(OperacionReal[1].find("Pow")+4, OperacionReal[1].find(",",OperacionReal[1].find("Pow"))):
                         BasePotencia = BasePotencia + str(OperacionReal[1][i])
                     for i in range(OperacionReal[1].find(",", OperacionReal[1].find("Pow"))+2, OperacionReal[1].find("]", OperacionReal[1].find("Pow"))):
                         Elevado = Elevado + str(OperacionReal[1][i])
                     ResultadoPotencia = float(BasePotencia) ** float (Elevado)

                     # Reemplazar el string original con el resultado:
                     OperacionPHecha = ""
                     for i in range(0, OperacionReal[1].find("Pow")):
                         OperacionPHecha = OperacionPHecha + OperacionReal[1][i]
                     OperacionPHecha = OperacionPHecha + str(ResultadoPotencia)
                     for i in range((OperacionReal[1].find("]",OperacionReal[1].find("Pow"))) + 1, OperacionReal[1].find("\n", OperacionReal[1].find("Pow"))+1):
                         OperacionPHecha = OperacionPHecha + OperacionReal[1][i]
                
                 elif (OperacionReal[1].find("Pow") < 0):
                     OperacionPHecha = OperacionReal[1]

                 # Factorial
                 NDelFact = ""
                 if (OperacionPHecha.find("Fact") > -1):
                   for i in range((OperacionPHecha.find("Fact")+5), (OperacionPHecha.find("]",OperacionPHecha.find("Fact")))):
                       NDelFact = NDelFact + OperacionPHecha[i]

                   ResultadoFact = math.factorial(int(NDelFact))
                   # Reemplazar el string original con el resultado:
                   OperacionFHecho = ""

                   for i in range(0, (OperacionPHecha.find("Fact"))):
                       OperacionFHecho = OperacionFHecho + OperacionPHecha[i]

                   OperacionFHecho = OperacionFHecho + str(ResultadoFact)

                   for i in range((OperacionPHecha.find("]", OperacionPHecha.find("Fact")))+1, (OperacionPHecha.find("\n", OperacionPHecha.find("Fact")))+1):
                       OperacionFHecho = OperacionFHecho + OperacionPHecha[i]

                 elif (OperacionPHecha.find("Fact")<0):
                     OperacionFHecho = OperacionPHecha

                 #Raices
                 NumeroDentroRaiz = ""
                 if (OperacionFHecho.find("Sqrt") > -1):
                     for i in range (OperacionFHecho.find("Sqrt")+5, OperacionFHecho.find("]",OperacionFHecho.find("Sqrt"))):
                         NumeroDentroRaiz = NumeroDentroRaiz + OperacionFHecho[i]
                     ResultadoRaiz = math.sqrt(float(NumeroDentroRaiz))

                     # Reemplazar el string original con el resultado:
                     OperacionRHecha = ""

                     for i in range(0, (OperacionFHecho.find("Sqrt"))):
                         OperacionRHecha = OperacionRHecha + OperacionFHecho[i]

                     OperacionRHecha = OperacionRHecha + str(ResultadoRaiz)

                     for i in range(OperacionFHecho.find("]",OperacionFHecho.find("Sqrt"))+1, (OperacionFHecho.find("\n", OperacionFHecho.find("Sqrt")))+1):
                         OperacionRHecha = OperacionRHecha + OperacionFHecho[i]

                 elif (OperacionFHecho.find("Sqrt") < 0):
                     OperacionRHecha = OperacionFHecho

                 '''
                 #Convertir a Postfija
                 ListaInfija = OperacionRHecha.split()
                 Operadores = []
                 NotacionPostFijaIn = ""
                 PrecedenciaOperadores = {"(": 0,")": 0,"+": 1, "-": 1, "*": 2, "/": 2, "^": 3}

                 #for que recorre la operacion:
                 for i in range(0,len(ListaInfija)):
                     if ListaInfija[0] == "(":
                         Operadores.append(ListaInfija.pop(0))
                     elif ListaInfija[0] == ")":
                         ListaInfija.pop(0)
                         while Operadores[0] != "(":
                             NotacionPostFijaIn = NotacionPostFijaIn + " " + Operadores.pop(0)
                         Operadores.pop(0)
                     elif (ListaInfija[0] == "+" or ListaInfija[0] == "-" or ListaInfija[0] == "*" or ListaInfija[0] == "/"):
                         if len(Operadores) < 1:
                             Operadores.append(ListaInfija.pop(0))
                         elif PrecedenciaOperadores[ListaInfija[0]] > PrecedenciaOperadores[Operadores[len(Operadores)-1]]:
                             Operadores.append(ListaInfija.pop(0))
                         elif PrecedenciaOperadores[ListaInfija[0]] <= PrecedenciaOperadores[Operadores[len(Operadores)-1]]:

                             while  len(Operadores)>0:
                               NotacionPostFijaIn = NotacionPostFijaIn + " " + Operadores.pop(len(Operadores)-1)
                             Operadores.append(ListaInfija.pop(0))

                     else:
                         NotacionPostFijaIn = NotacionPostFijaIn + " " + ListaInfija.pop(0)
                 for i in range(0,len(Operadores)):
                     NotacionPostFijaIn = NotacionPostFijaIn + " " + Operadores.pop(0)

                 print("Esto es postfija")
                 print(NotacionPostFijaIn)

                 #Operacion Postfija
                 ListaOperacionPostFija = NotacionPostFijaIn.split()
                 ProcesoIntermedio = []
                 for i in range(0, len(ListaOperacionPostFija)):
                     if ListaOperacionPostFija[0] == "+":
                         ListaOperacionPostFija.pop(0)
                         Operando2 = ProcesoIntermedio.pop()
                         Operando1 = ProcesoIntermedio.pop()
                         ResultadoSuma = float(Operando1) + float(Operando2)
                         ProcesoIntermedio.append(ResultadoSuma)

                     elif ListaOperacionPostFija[0] == "-":
                         ListaOperacionPostFija.pop(0)
                         Operando2 = ProcesoIntermedio.pop()
                         Operando1 = ProcesoIntermedio.pop()
                         ResultadoResta = float(Operando1) - float(Operando2)
                         ProcesoIntermedio.append(ResultadoResta)

                     elif ListaOperacionPostFija[0] == "*":
                         ListaOperacionPostFija.pop(0)
                         Operando2 = ProcesoIntermedio.pop()
                         Operando1 = ProcesoIntermedio.pop()
                         ResultadoMult = float(Operando1) * float(Operando2)
                         ProcesoIntermedio.append(ResultadoMult)

                     elif ListaOperacionPostFija[0] == "/":
                         ListaOperacionPostFija.pop(0)
                         Operando2 = ProcesoIntermedio.pop()
                         Operando1 = ProcesoIntermedio.pop()
                         ResultadoDiv = float(Operando1) / float(Operando2)
                         ProcesoIntermedio.append(ResultadoDiv)

                     else:
                         ProcesoIntermedio.append(ListaOperacionPostFija.pop(0))
                     '''
                 # El Resto del String
                 print("--> Post: ", end="")
                 print("Aquí pondría mi Notación Postfija si tuviera una.jpg")
                 print("Resultado: ", end = "")
                 print("F Por mi practica :(")
                 print("")

             elif LineaParaPartir.startswith("POST:"):
                 # Separar la Operación Real y escribirla en el GUI:
                 OperacionReal = Linea.split(":")
                 print("Operación: ", end="")
                 print(OperacionReal[1], end="")

                 # Realizar Potencias, Factoriales y otras operaciones que no pueden ser separadas despues para facilitar el trabajo
                 # Potencias

                 # Lista que guardará la Potencia a realizar:
                 if (OperacionReal[1].find("Pow") > -1):
                     BasePotencia = ""
                     Elevado = ""
                     for i in range(OperacionReal[1].find("Pow") + 4,
                                    OperacionReal[1].find(",", OperacionReal[1].find("Pow"))):
                         BasePotencia = BasePotencia + str(OperacionReal[1][i])
                     for i in range(OperacionReal[1].find(",", OperacionReal[1].find("Pow")) + 2,
                                    OperacionReal[1].find("]", OperacionReal[1].find("Pow"))):
                         Elevado = Elevado + str(OperacionReal[1][i])
                     ResultadoPotencia = float(BasePotencia) ** float(Elevado)

                     # Reemplazar el string original con el resultado:
                     OperacionPHecha = ""
                     for i in range(0, OperacionReal[1].find("Pow")):
                         OperacionPHecha = OperacionPHecha + OperacionReal[1][i]
                     OperacionPHecha = OperacionPHecha + str(ResultadoPotencia)
                     for i in range((OperacionReal[1].find("]", OperacionReal[1].find("Pow"))) + 1,
                                    OperacionReal[1].find("\n", OperacionReal[1].find("Pow")) + 1):
                         OperacionPHecha = OperacionPHecha + OperacionReal[1][i]

                 elif (OperacionReal[1].find("Pow") < 0):
                     OperacionPHecha = OperacionReal[1]

                 # Factorial
                 NDelFact = ""
                 if (OperacionPHecha.find("Fact") > -1):
                     for i in range((OperacionPHecha.find("Fact") + 5),
                                    (OperacionPHecha.find("]", OperacionPHecha.find("Fact")))):
                         NDelFact = NDelFact + OperacionPHecha[i]

                     ResultadoFact = math.factorial(int(NDelFact))
                     # Reemplazar el string original con el resultado:
                     OperacionFHecho = ""

                     for i in range(0, (OperacionPHecha.find("Fact"))):
                         OperacionFHecho = OperacionFHecho + OperacionPHecha[i]

                     OperacionFHecho = OperacionFHecho + str(ResultadoFact)

                     for i in range((OperacionPHecha.find("]", OperacionPHecha.find("Fact"))) + 1,
                                    (OperacionPHecha.find("\n", OperacionPHecha.find("Fact"))) + 1):
                         OperacionFHecho = OperacionFHecho + OperacionPHecha[i]

                 elif (OperacionPHecha.find("Fact") < 0):
                     OperacionFHecho = OperacionPHecha

                 # Raices
                 NumeroDentroRaiz = ""
                 if (OperacionFHecho.find("Sqrt") > -1):
                     for i in range(OperacionFHecho.find("Sqrt") + 5,
                                    OperacionFHecho.find("]", OperacionFHecho.find("Sqrt"))):
                         NumeroDentroRaiz = NumeroDentroRaiz + OperacionFHecho[i]
                     ResultadoRaiz = math.sqrt(float(NumeroDentroRaiz))

                     # Reemplazar el string original con el resultado:
                     OperacionRHecha = ""

                     for i in range(0, (OperacionFHecho.find("Sqrt"))):
                         OperacionRHecha = OperacionRHecha + OperacionFHecho[i]

                     OperacionRHecha = OperacionRHecha + str(ResultadoRaiz)

                     print(str(OperacionFHecho.find("]", OperacionFHecho.find("Sqrt"))))
                     print(str(OperacionFHecho.find("\n")))

                     for i in range(OperacionFHecho.find("]", OperacionFHecho.find("Sqrt")) + 1,
                                    (OperacionFHecho.find("\n", OperacionFHecho.find("Sqrt"))) + 1):
                         OperacionRHecha = OperacionRHecha + OperacionFHecho[i]

                 elif (OperacionFHecho.find("Sqrt") < 0):
                     OperacionRHecha = OperacionFHecho


                 #Operacion PostFija
                 ListaOperacionPostFija = OperacionRHecha.split()
                 ProcesoIntermedio = []
                 for i in range(0, len(ListaOperacionPostFija)) :
                     if ListaOperacionPostFija[0] == "+":
                         ListaOperacionPostFija.pop(0)
                         Operando2=ProcesoIntermedio.pop()
                         Operando1=ProcesoIntermedio.pop()
                         ResultadoSuma = float(Operando1) + float(Operando2)
                         ProcesoIntermedio.append(ResultadoSuma)

                     elif ListaOperacionPostFija[0] == "-":
                         ListaOperacionPostFija.pop(0)
                         Operando2 = ProcesoIntermedio.pop()
                         Operando1 = ProcesoIntermedio.pop()
                         ResultadoResta = float(Operando1) - float(Operando2)
                         ProcesoIntermedio.append(ResultadoResta)

                     elif ListaOperacionPostFija[0] == "*":
                         ListaOperacionPostFija.pop(0)
                         Operando2 = ProcesoIntermedio.pop()
                         Operando1 = ProcesoIntermedio.pop()
                         ResultadoMult = float(Operando1) * float(Operando2)
                         ProcesoIntermedio.append(ResultadoMult)

                     elif ListaOperacionPostFija[0] == "/":
                         ListaOperacionPostFija.pop(0)
                         Operando2 = ProcesoIntermedio.pop()
                         Operando1 = ProcesoIntermedio.pop()
                         ResultadoDiv= float(Operando1) / float(Operando2)
                         ProcesoIntermedio.append(ResultadoDiv)

                     else:
                         ProcesoIntermedio.append(ListaOperacionPostFija.pop(0))

                 # El Resto del String
                 print("Resultado: ", end = "")
                 print(ProcesoIntermedio)
                 print ("")

             elif LineaParaPartir.startswith("PRE:"):
                 # Separar la Operación Real y escribirla en el GUI:
                 OperacionReal = Linea.split(":")
                 print("Operación: ", end="")
                 print(OperacionReal[1], end="")

                 # Realizar Potencias, Factoriales y otras operaciones que no pueden ser separadas despues para facilitar el trabajo
                 # Potencias

                 # Lista que guardará la Potencia a realizar:
                 if (OperacionReal[1].find("Pow") > -1):
                     BasePotencia = ""
                     Elevado = ""
                     for i in range(OperacionReal[1].find("Pow") + 4,
                                    OperacionReal[1].find(",", OperacionReal[1].find("Pow"))):
                         BasePotencia = BasePotencia + str(OperacionReal[1][i])
                     for i in range(OperacionReal[1].find(",", OperacionReal[1].find("Pow")) + 2,
                                    OperacionReal[1].find("]", OperacionReal[1].find("Pow"))):
                         Elevado = Elevado + str(OperacionReal[1][i])
                     ResultadoPotencia = float(BasePotencia) ** float(Elevado)

                     # Reemplazar el string original con el resultado:
                     OperacionPHecha = ""
                     for i in range(0, OperacionReal[1].find("Pow")):
                         OperacionPHecha = OperacionPHecha + OperacionReal[1][i]
                     OperacionPHecha = OperacionPHecha + str(ResultadoPotencia)
                     for i in range((OperacionReal[1].find("]", OperacionReal[1].find("Pow"))) + 1,
                                    OperacionReal[1].find("\n", OperacionReal[1].find("Pow")) + 1):
                         OperacionPHecha = OperacionPHecha + OperacionReal[1][i]

                 elif (OperacionReal[1].find("Pow") < 0):
                     OperacionPHecha = OperacionReal[1]

                 # Factorial
                 NDelFact = ""
                 if (OperacionPHecha.find("Fact") > -1):
                     for i in range((OperacionPHecha.find("Fact") + 5),
                                    (OperacionPHecha.find("]", OperacionPHecha.find("Fact")))):
                         NDelFact = NDelFact + OperacionPHecha[i]

                     ResultadoFact = math.factorial(int(NDelFact))
                     # Reemplazar el string original con el resultado:
                     OperacionFHecho = ""

                     for i in range(0, (OperacionPHecha.find("Fact"))):
                         OperacionFHecho = OperacionFHecho + OperacionPHecha[i]

                     OperacionFHecho = OperacionFHecho + str(ResultadoFact)

                     for i in range((OperacionPHecha.find("]", OperacionPHecha.find("Fact"))) + 1,
                                    (OperacionPHecha.find("\n", OperacionPHecha.find("Fact"))) + 1):
                         OperacionFHecho = OperacionFHecho + OperacionPHecha[i]

                 elif (OperacionPHecha.find("Fact") < 0):
                     OperacionFHecho = OperacionPHecha

                 # Raices
                 NumeroDentroRaiz = ""
                 if (OperacionFHecho.find("Sqrt") > -1):
                     for i in range(OperacionFHecho.find("Sqrt") + 5,
                                    OperacionFHecho.find("]", OperacionFHecho.find("Sqrt"))):
                         NumeroDentroRaiz = NumeroDentroRaiz + OperacionFHecho[i]
                     ResultadoRaiz = math.sqrt(float(NumeroDentroRaiz))

                     # Reemplazar el string original con el resultado:
                     OperacionRHecha = ""

                     for i in range(0, (OperacionFHecho.find("Sqrt"))):
                         OperacionRHecha = OperacionRHecha + OperacionFHecho[i]

                     OperacionRHecha = OperacionRHecha + str(ResultadoRaiz)

                     print(str(OperacionFHecho.find("]", OperacionFHecho.find("Sqrt"))))
                     print(str(OperacionFHecho.find("\n")))

                     for i in range(OperacionFHecho.find("]", OperacionFHecho.find("Sqrt")) + 1,
                                    (OperacionFHecho.find("\n", OperacionFHecho.find("Sqrt"))) + 1):
                         OperacionRHecha = OperacionRHecha + OperacionFHecho[i]

                 elif (OperacionFHecho.find("Sqrt") < 0):
                     OperacionRHecha = OperacionFHecho


                 #Convertir Prefija a Postfija
                 ListaPrefijaaPostfija = OperacionRHecha.split()
                 ListaPrefijaaPostfija.reverse()
                 NotacionPostFijaPre = ""
                 for i in range (0,len(ListaPrefijaaPostfija)):
                  NotacionPostFijaPre = NotacionPostFijaPre + ListaPrefijaaPostfija[i] + " "

                 #Resolver la Postfija
                 ListaOperacionPostFija = ListaPrefijaaPostfija
                 ProcesoIntermedio = []
                 for i in range(0, len(ListaOperacionPostFija)):
                     if ListaOperacionPostFija[0] == "+":
                         ListaOperacionPostFija.pop(0)
                         Operando1 = ProcesoIntermedio.pop()
                         Operando2 = ProcesoIntermedio.pop()
                         ResultadoSuma = float(Operando1) + float(Operando2)
                         ProcesoIntermedio.append(ResultadoSuma)

                     elif ListaOperacionPostFija[0] == "-":
                         ListaOperacionPostFija.pop(0)
                         Operando1 = ProcesoIntermedio.pop()
                         Operando2 = ProcesoIntermedio.pop()
                         ResultadoResta = float(Operando1) - float(Operando2)
                         ProcesoIntermedio.append(ResultadoResta)

                     elif ListaOperacionPostFija[0] == "*":
                         ListaOperacionPostFija.pop(0)
                         Operando1 = ProcesoIntermedio.pop()
                         Operando2 = ProcesoIntermedio.pop()
                         ResultadoMult = float(Operando1) * float(Operando2)
                         ProcesoIntermedio.append(ResultadoMult)

                     elif ListaOperacionPostFija[0] == "/":
                         ListaOperacionPostFija.pop(0)
                         Operando1 = ProcesoIntermedio.pop()
                         Operando2 = ProcesoIntermedio.pop()
                         ResultadoDiv = float(Operando1) / float(Operando2)
                         ProcesoIntermedio.append(ResultadoDiv)

                     else:
                         ProcesoIntermedio.append(ListaOperacionPostFija.pop(0))

                 # El Resto del String
                 print("--> Post: ", end="")
                 print(NotacionPostFijaPre)
                 print("Resultado: ", end = "")
                 print(ProcesoIntermedio)
                 print("")

        print()
        input("Ingrese cualquier valor para volver al Menú Principal: ")
    else:
        input("Solo puede ingresar un archivo con extensión '.lfp', ingrese cualquier valor para volver al Menú Principal: ")
