import sys
from CargarArchivo import CargarArchivo
def GUI():
  #Caja Datos Alumno
    # Linea Superior
    for x in range(0, 42):
      print("-", end="")

    #Un Salto de Línea
    print()

    #Datos
    print("| Nombre: Bryan Steve Montepeque Santos  |")
    print("| Carnet: 201700375                      |")

    # Linea Inferior
    for x in range(0, 42):
     print("-", end="")


  #Caja Opciones Menú

    #Un Salto de Linea
    print()

    #Partes Intermedias

    print("| 1. Cargar Archivo                      |")
    print("| 2. Graficar Operación                  |")
    print("| 3. Salir                               |")

    #Linea Inferior
    for x in range (0,42):
        print("-", end = "")

    # Un Salto de Linea
    print()

    #Texto e Input con Opciones y Try Except
    try:
     OpcionMenu = int (input("Bienvenido, Ingrese el Número de la Operación que desee realizar: "))
     if OpcionMenu == 1:
         CargarArchivo()
         GUI()
     elif OpcionMenu == 2:
         print("Graficar")
     elif OpcionMenu == 3:
         sys.exit()
    except ValueError:
        print("Solo Puede Ingresar el Número de la función, por ejemplo, ingrese '1' si desea cargar un archivo, Intentelo de nuevo ")
        print()
        GUI()



