import os
with open("grafo_salida.dot",mode="w") as f:
    f.write("digraph dibujo{\n");
    f.write("hello->world;\n");
    f.write("world->lenguajes;\n");
    f.write("formales->Bmenos;\n");
    f.write("Frutas[shape=box,shape=circle,label=\"FRUTAS\"];" );
    f.write("}\n");

os.system('dot -Tpng grafo_salida.dot -o salida.png');