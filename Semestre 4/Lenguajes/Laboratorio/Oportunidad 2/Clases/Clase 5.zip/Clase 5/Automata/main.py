"""
Implementación de un AFD en Python que reconoce, palabras, números con punto decimal y comas.
Material de apoyo elaborado por Danilo Urias Coc
Tutor académico Lenguajes Formales y de Programación Sección B-
Febrero de 2021
"""

contenido_archivo=""
estado=0
char_actual= ""
lexema=""

#Lectura del archivo de entrada --------------------
with open('entrada.txt', "r") as f:
	contenido_archivo=f.read()

#Le agrego un espacio en blanco al final para no perder el último lexema
#Si se comenta la linea se puede observar su funcionalidad
contenido_archivo=contenido_archivo+" "

#----------------------------------------------------
# Con este metodo compruebo si se trata de una letra
#-----------------------------------------------------
def esletra(caracter):
	letras=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","Ñ","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
	if caracter.upper() in letras:
		return True
	else:
		return False


#-------------------------------------------------------
# Con este metodo compruebo si se trata de un numero
#-------------------------------------------------------
def esnumero(caracter):
	digitos=["0","1","2","3","4","5","6","7","8","9"]
	if caracter in digitos:
		return True
	else:
		return False

"Inicio un contador que servirá de indice para recorrer la cadena que contiene el texto del archivo"
x=0
while x<len(contenido_archivo):
	char_actual = contenido_archivo[x]
	#--------------------------------------
	#  ESTADO CERO
	#--------------------------------------
	if estado==0:
		# transiciones desde el estado 0 ....
		if esletra(char_actual):
			estado = 3
			lexema = lexema + char_actual
		elif esnumero(char_actual):
			estado = 1
			lexema = lexema + char_actual
		elif char_actual == ",":
			print("se reconocio una coma: "+char_actual)
		elif char_actual == " ":
			print("se ignoro un espacio")
		elif char_actual == "\n":
			print("se ignoro un salto")
		else:
			print("Se encontro un error en :"+char_actual)
		# ------------- ESTADO UNO
	#--------------------------------------
	#  ESTADO UNO
	#--------------------------------------
	elif estado == 1:
		# transiciones desde el estado 1 ....
		if esnumero(char_actual):
			lexema = lexema + char_actual
			estado = 1
		elif char_actual == ".":
			lexema = lexema + char_actual
			estado = 2
		else:
			print("se encontro un error en " + char_actual)
			lexema = ""
			estado = 0
	#--------------------------------------
	#  ESTADO DOS
	#--------------------------------------
	elif estado == 2:
		#transiciones desde el estado 2 ....
		if esnumero(char_actual):
			lexema = lexema + char_actual
			estado = 2
		else:
			estado = 0
			x = x - 1
			print("Se reconocio un numero: " + lexema)
			lexema = ""
	# --------------------------------------
	#  ESTADO TRES
	# --------------------------------------
	elif estado == 3:
		# transiciones desde el estado 3 ....
		if esletra(char_actual):
			estado = 3
			lexema = lexema + char_actual
		else:
			estado = 0
			x = x - 1
			print("Se reconocio una palabra: " + lexema)
			lexema = ""
	x=x+1
