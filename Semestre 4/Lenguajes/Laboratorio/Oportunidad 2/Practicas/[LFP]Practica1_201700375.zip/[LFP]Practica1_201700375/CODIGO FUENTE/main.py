import sys
import webbrowser
import tkinter as tk
from tkinter import filedialog
#Crear Ventana Raiz para manejar mejor el Tkinter
root = tk.Tk()

#Listas:
ListaOrdenadas = []
ListaBuscar = []
ListaNumerosABuscar = []
ListaTodas = []

#Variable que guarda el archivo:
ArchivoAbierto = ''

def CargarArchivo():
    print("Cargar Archivo: ")
    print('')
    global ArchivoAbierto
    ListaOrdenadas.clear()
    ListaBuscar.clear()
    ListaTodas.clear()
    ArchivoAbierto = ''
    filters = (("Archivos de Texto", "*.txt"), ("Todos los Archivos", "*.*"))
    ArchivoAbierto = tk.filedialog.askopenfilename(filetypes=filters)
    root.destroy()
    print(ArchivoAbierto)
    print('')
    input("Archivo Cargado, ingrese cualquier valor para volver al Menú Principal: ")
    Menu()

def Ordenadas():
    #Variables a usar:
    NombreLista = ''
    StringResultado = ''
    ListaOrdenadas.clear()
    ListaBuscar.clear()
    ListaTodas.clear()
    if ArchivoAbierto == '':
        input("No se ha cargado ningun archivo, ingrese un valor para volver al Menú Principal: ")
        Menu()
    else:
        print('Desplegar Listas Ordenadas:')
        print('')
        with open(ArchivoAbierto, "r") as Archivo:
            for Linea in Archivo:
                LineaPartidaEnEspacio = Linea.split(" ")
                SegmentoInstruccionesPartidoEnComas = LineaPartidaEnEspacio[1].split(",")
                if SegmentoInstruccionesPartidoEnComas[0].upper() == "ORDENAR" or LineaPartidaEnEspacio[1].rstrip().upper() == "ORDENAR":
                    ListaOrdenadas.append(Linea.rstrip())
            Archivo.close()
            for Item in ListaOrdenadas:
                StringResultado = ''
                LineaPartidaEnIgual = Item.split('=')
                NombreLista = LineaPartidaEnIgual[0]
                StringResultado = StringResultado + NombreLista + ": "
                LineaSoloDatos = LineaPartidaEnIgual[1].split(" ")
                DatosEnSi = LineaSoloDatos[0].split(",")
                StringResultado = StringResultado + ",".join(DatosEnSi) + "|"
                #Ordenamiento Chido ;v
                for i in range(len(DatosEnSi)):
                    for j in range(0,len(DatosEnSi)-1):
                        if DatosEnSi[j] > DatosEnSi[j+1]:
                            DatosEnSi[j],DatosEnSi[j+1] = DatosEnSi[j+1],DatosEnSi[j]
                StringResultado = StringResultado + " Resultado de Ordenar: " + ",".join(DatosEnSi)
                print(StringResultado)
        print('')
        input("Ingrese cualquier valor para volver al Menú: ")
        Menu()

def Busquedas():
    #Variables a usar:
    NombreLista = ''
    StringResultado = ''
    ListaOrdenadas.clear()
    ListaBuscar.clear()
    ListaTodas.clear()
    if ArchivoAbierto == '':
        input("No se ha cargado ningun archivo, ingrese un valor para volver al Menú Principal: ")
        Menu()
    else:
        print('Desplegar Listas de Busqueda:')
        print('')
        with open(ArchivoAbierto, "r") as Archivo:
            for Linea in Archivo:
                #Partido en Instrucciones y Datos
                LineaPartidaEnEspacio = Linea.split(" ")

                if LineaPartidaEnEspacio[1].upper() == "ORDENAR,BUSCAR":
                    SegmentoInstruccionesPartidas2Veces = LineaPartidaEnEspacio[1].split(",")
                    if SegmentoInstruccionesPartidas2Veces[1].upper()=="BUSCAR":
                        ListaBuscar.append(Linea.rstrip())
                        NumeroABuscar = LineaPartidaEnEspacio[2]
                        ListaNumerosABuscar.append(NumeroABuscar)
                elif LineaPartidaEnEspacio[1].upper() == "BUSCAR":
                    ListaBuscar.append(Linea.rstrip())
                    NumeroABuscar = LineaPartidaEnEspacio[2]
                    ListaNumerosABuscar.append(NumeroABuscar)
            Archivo.close()
            #Analisis en sí
            IndexNumeros = -1
            for Item in ListaBuscar:
                IndexNumeros= IndexNumeros + 1
                #Crear String
                StringResultado = ''

                #Obtener Nombre Lista
                LineaPartidaEnIgual = Item.split('=')
                NombreLista = LineaPartidaEnIgual[0]

                #Meter Nombre Lista al String
                StringResultado = StringResultado + NombreLista + ": "

                #Aislar los números
                LineaSoloDatos = LineaPartidaEnIgual[1].split(" ")
                DatosEnSi = LineaSoloDatos[0].split(",")

                #Agregar Número Buscado al String
                StringResultado = StringResultado + ",".join(DatosEnSi) + "|" + " Valor Buscado: " + ListaNumerosABuscar[IndexNumeros].rstrip() + " |"

                #Busqueda Chida ;v
                ListaDeOcurrencias = []
                for i in range(len(DatosEnSi)):
                    if DatosEnSi[i] == ListaNumerosABuscar[IndexNumeros].rstrip():
                        ListaDeOcurrencias.append(str(i+1))
                if not ListaDeOcurrencias:
                    StringResultado = StringResultado + " No Encontrado :("
                else:
                    StringResultado = StringResultado + " Entonctrado En: " + ",".join(ListaDeOcurrencias)
                print(StringResultado)
        print('')
        input("Ingrese cualquier valor para volver al Menú: ")
        Menu()

def Todas():
    #Variables a usar:
    NombreLista = ''
    StringResultadoBusqueda = ''
    StringResultadoOrdenar = ''
    ListaOrdenadas.clear()
    ListaBuscar.clear()
    ListaTodas.clear()
    if ArchivoAbierto == '':
        input("No se ha cargado ningun archivo, ingrese un valor para volver al Menú Principal: ")
        Menu()
    else:
        print('Desplegar Todas:')
        print('')
        with open(ArchivoAbierto, "r") as Archivo:
            for Linea in Archivo:
            #Parte Ordenar:
                LineaPartidaEnEspacio = Linea.split(" ")
                SegmentoInstruccionesPartidoEnComas = LineaPartidaEnEspacio[1].split(",")
                if SegmentoInstruccionesPartidoEnComas[0].upper() == "ORDENAR" or LineaPartidaEnEspacio[1].rstrip().upper() == "ORDENAR":
                    ListaOrdenadas.append(Linea.rstrip())

            #Parte Buscar:
                #Partido en Instrucciones y Datos
                LineaPartidaEnEspacio = Linea.split(" ")

                if LineaPartidaEnEspacio[1].upper() == "ORDENAR,BUSCAR":
                    SegmentoInstruccionesPartidas2Veces = LineaPartidaEnEspacio[1].split(",")
                    if SegmentoInstruccionesPartidas2Veces[1].upper()=="BUSCAR":
                        ListaBuscar.append(Linea.rstrip())
                        NumeroABuscar = LineaPartidaEnEspacio[2]
                        ListaNumerosABuscar.append(NumeroABuscar)
                elif LineaPartidaEnEspacio[1].upper() == "BUSCAR":
                    ListaBuscar.append(Linea.rstrip())
                    NumeroABuscar = LineaPartidaEnEspacio[2]
                    ListaNumerosABuscar.append(NumeroABuscar)
            Archivo.close()
            #Analisis en sí

            #Ordenar Requiem:
            for Item in ListaOrdenadas:
                StringResultadoOrdenar = ''
                LineaPartidaEnIgual = Item.split('=')
                NombreLista = LineaPartidaEnIgual[0]
                StringResultadoOrdenar = StringResultadoOrdenar + NombreLista + ": "
                LineaSoloDatos = LineaPartidaEnIgual[1].split(" ")
                DatosEnSi = LineaSoloDatos[0].split(",")
                StringResultadoOrdenar = StringResultadoOrdenar + ",".join(DatosEnSi) + "|"
                # Ordenamiento Chido ;v
                for i in range(len(DatosEnSi)):
                    for j in range(0, len(DatosEnSi) - 1):
                        if DatosEnSi[j] > DatosEnSi[j + 1]:
                            DatosEnSi[j], DatosEnSi[j + 1] = DatosEnSi[j + 1], DatosEnSi[j]
                StringResultadoOrdenar = StringResultadoOrdenar + " Resultado de Ordenar: " + ",".join(DatosEnSi)
                print(StringResultadoOrdenar)

            #Buscar Requiem:
            IndexNumeros = -1
            for Item in ListaBuscar:
                IndexNumeros= IndexNumeros + 1
                #Crear String
                StringResultadoBusqueda = ''

                #Obtener Nombre Lista
                LineaPartidaEnIgual = Item.split('=')
                NombreLista = LineaPartidaEnIgual[0]

                #Meter Nombre Lista al String
                StringResultadoBusqueda = StringResultadoBusqueda + NombreLista + ": "

                #Aislar los números
                LineaSoloDatos = LineaPartidaEnIgual[1].split(" ")
                DatosEnSi = LineaSoloDatos[0].split(",")

                #Agregar Número Buscado al String
                StringResultadoBusqueda = StringResultadoBusqueda + ",".join(DatosEnSi) + "|" + " Valor Buscado: " + ListaNumerosABuscar[IndexNumeros].rstrip() + " |"

                #Busqueda Chida ;v
                ListaDeOcurrencias = []
                for i in range(len(DatosEnSi)):
                    if DatosEnSi[i] == ListaNumerosABuscar[IndexNumeros].rstrip():
                        ListaDeOcurrencias.append(str(i+1))
                if not ListaDeOcurrencias:
                    StringResultadoBusqueda = StringResultadoBusqueda + " No Encontrado :("
                else:
                    StringResultadoBusqueda = StringResultadoBusqueda + " Entonctrado En: " + ",".join(ListaDeOcurrencias)
                print(StringResultadoBusqueda)
        print('')
        input("Ingrese cualquier valor para volver al Menú: ")
        Menu()

def TodasAHTML():
    #Variables a usar:
    NombreLista = ''
    StringResultadoBusqueda = ''
    StringResultadoOrdenar = ''
    ListaOrdenadas.clear()
    ListaBuscar.clear()
    ListaTodas.clear()

    # Inicio del Archivo HTML
    StringDocumentoHTML = '<!DOCTYPE html>\n<html>\n  <head>\n<style>\n table, th, td {\n border: 1px solid black;\n}\n</style>\n<title>Listas en HTML</title>\n   </head>\n   <body>\n '
    #Titulo Archivo:
    StringDocumentoHTML = StringDocumentoHTML + '<h1>Lenguajes Formales y de Programación Practica Unica</h1>\n<h2>Listas Ingresadas en el Archivo: </h2>\n'
    # Crear Tabla Ordenar
    StringDocumentoHTML = StringDocumentoHTML + '<table>\n  <tr>\n  <th bgcolor = #E9967A>Nombre Lista</th>\n <th bgcolor = #E9967A>Datos Calculados</th>\n</tr>\n'

    if ArchivoAbierto == '':
        input("No se ha cargado ningun archivo, ingrese un valor para volver al Menú Principal: ")
        Menu()
    else:
        print('Desplegar Todas a HTML:')
        print('')
        with open(ArchivoAbierto, "r") as Archivo:
            for Linea in Archivo:
            #Parte Ordenar:
                LineaPartidaEnEspacio = Linea.split(" ")
                SegmentoInstruccionesPartidoEnComas = LineaPartidaEnEspacio[1].split(",")
                if SegmentoInstruccionesPartidoEnComas[0].upper() == "ORDENAR" or LineaPartidaEnEspacio[1].rstrip().upper() == "ORDENAR":
                    ListaOrdenadas.append(Linea.rstrip())

            #Parte Buscar:
                #Partido en Instrucciones y Datos
                LineaPartidaEnEspacio = Linea.split(" ")

                if LineaPartidaEnEspacio[1].upper() == "ORDENAR,BUSCAR":
                    SegmentoInstruccionesPartidas2Veces = LineaPartidaEnEspacio[1].split(",")
                    if SegmentoInstruccionesPartidas2Veces[1].upper()=="BUSCAR":
                        ListaBuscar.append(Linea.rstrip())
                        NumeroABuscar = LineaPartidaEnEspacio[2]
                        ListaNumerosABuscar.append(NumeroABuscar)
                elif LineaPartidaEnEspacio[1].upper() == "BUSCAR":
                    ListaBuscar.append(Linea.rstrip())
                    NumeroABuscar = LineaPartidaEnEspacio[2]
                    ListaNumerosABuscar.append(NumeroABuscar)
            Archivo.close()

            #Analisis en sí
            #Ordenar Requiem:
            for Item in ListaOrdenadas:
                StringResultadoOrdenar = ''
                LineaPartidaEnIgual = Item.split('=')
                NombreLista = LineaPartidaEnIgual[0]
                StringResultadoOrdenar = StringResultadoOrdenar + NombreLista + ": "
                LineaSoloDatos = LineaPartidaEnIgual[1].split(" ")
                DatosEnSi = LineaSoloDatos[0].split(",")
                StringResultadoOrdenar = StringResultadoOrdenar + ",".join(DatosEnSi) + "|"
                # Ordenamiento Chido ;v
                for i in range(len(DatosEnSi)):
                    for j in range(0, len(DatosEnSi) - 1):
                        if DatosEnSi[j] > DatosEnSi[j + 1]:
                            DatosEnSi[j], DatosEnSi[j + 1] = DatosEnSi[j + 1], DatosEnSi[j]
                StringResultadoOrdenar = StringResultadoOrdenar + " Resultado de Ordenar: " + ",".join(DatosEnSi)
                print(StringResultadoOrdenar)
                StringDocumentoHTML = StringDocumentoHTML + '<tr style="background-color:#87CEFA">\n     <td>' + NombreLista + "</td>\n  <td>" + StringResultadoOrdenar + '</td>\n</tr>'

            #Buscar Requiem:
            IndexNumeros = -1
            for Item in ListaBuscar:
                IndexNumeros= IndexNumeros + 1
                #Crear String
                StringResultadoBusqueda = ''

                #Obtener Nombre Lista
                LineaPartidaEnIgual = Item.split('=')
                NombreLista = LineaPartidaEnIgual[0]

                #Meter Nombre Lista al String
                StringResultadoBusqueda = StringResultadoBusqueda + NombreLista + ": "

                #Aislar los números
                LineaSoloDatos = LineaPartidaEnIgual[1].split(" ")
                DatosEnSi = LineaSoloDatos[0].split(",")

                #Agregar Número Buscado al String
                StringResultadoBusqueda = StringResultadoBusqueda + ",".join(DatosEnSi) + "|" + " Valor Buscado: " + ListaNumerosABuscar[IndexNumeros].rstrip() + " |"

                #Busqueda Chida ;v
                ListaDeOcurrencias = []
                for i in range(len(DatosEnSi)):
                    if DatosEnSi[i] == ListaNumerosABuscar[IndexNumeros].rstrip():
                        ListaDeOcurrencias.append(str(i+1))
                if not ListaDeOcurrencias:
                    StringResultadoBusqueda = StringResultadoBusqueda + " No Encontrado :("
                else:
                    StringResultadoBusqueda = StringResultadoBusqueda + " Entonctrado En: " + ",".join(ListaDeOcurrencias)
                print(StringResultadoBusqueda)
                StringDocumentoHTML = StringDocumentoHTML + '<tr style="background-color:#87CEFA">\n     <td>' + NombreLista + "</td>\n  <td>"+StringResultadoBusqueda+ '</td>\n</tr>'

        #Generar el HTML
        with open("ListasEnHTML.html", "w") as ArchivoHTML:
            #Terminar el String del HTML
            StringDocumentoHTML = StringDocumentoHTML + '</table>\n</body>\n</html>'
            ArchivoHTML.write(StringDocumentoHTML)
            print('')
            print("Ahorita te lo abro ;v")
            webbrowser.open('ListasEnHTML.html')
        print('')
        input("Ingrese cualquier valor para volver al Menú: ")
        Menu()

def Menu():
    # Caja Opciones Menú
    # Linea Superior
    for x in range(0, 42):
        print("-", end="")

    # Un Salto de Linea
    print()

    # Partes Intermedias

    print("| 1. Cargar Archivo                      |")
    print("| 2. Desplegar Listas Ordenadas          |")
    print("| 3. Desplegar Busquedas                 |")
    print("| 4. Desplegar Todas                     |")
    print("| 5. Desplegar Todas a Archivo           |")
    print("| 6. Salir                               |")

    # Linea Inferior
    for x in range(0, 42):
        print("-", end="")

    # Un Salto de Linea
    print()

    Valido = False
    while not Valido:
        # Texto e Input con Opciones y Try Except
        try:
            OpcionMenu = int(input("Bienvenido, Ingrese el Número de la Operación que desee realizar: "))
            if OpcionMenu == 1:
                CargarArchivo()
                Valido = True
            elif OpcionMenu == 2:
                Ordenadas()
                Valido = True
            elif OpcionMenu == 3:
                Busquedas()
                Valido = True
            elif OpcionMenu == 4:
                Todas()
                Valido = True
            elif OpcionMenu == 5:
                TodasAHTML()
                Valido = True
            elif OpcionMenu == 6:
                print("Carnet: 201700735")
                print("Nombre: Bryan Steve Montepeque Santos")
                print("Correo Electrónico: Bmontepeque11@gmail.com")
                print("Curso: Lenguajes Formales y de Programación")
                print("")
                input("Ingrese cualquieer valor para continuar: ")
                print("Entendible, Que tenga un Feliz Día.jpg :)")
                sys.exit()
            else:
                raise ValueError
        except ValueError:
            print(
                "Solo Puede Ingresar el Número de la función, por ejemplo, ingrese '1' si desea cargar un archivo, Intentelo de nuevo ")
        print()


#Funcion que inicia el programa
Menu()