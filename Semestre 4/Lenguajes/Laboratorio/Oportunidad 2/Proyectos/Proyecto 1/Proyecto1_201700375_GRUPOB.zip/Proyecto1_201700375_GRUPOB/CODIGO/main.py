import sys
import csv
import os
import webbrowser
import tkinter as tk
from tkinter import filedialog
#Crear Ventana Raiz para manejar mejor el Tkinter
root = tk.Tk()

##########################################
#Cosas Importantes
##########################################

#Variables Globales
##########################################
MenuAbierto = ''
OrdenAbierta = ''
NombreRestaurante= ''
CuentaDePuntos = 0

#Listas
###########################################
ListaTokens = []  # Esto es para la tabla, cada nodo de la lista es un Token
ListaErrores = []  # Esto es para la tabla, cada nodo de la lista es un Error
ListaErroresOrden = []
ListaSecciones = []
ListaBebidas = []
ListaDesayunos = []
ListaPostres = []

ListaCaracteresEspecialesMenu = ["!", "#", "*", "$", "&", "%", "+", "-", "@"]




##########################################
#Seccion
##########################################

class Seccion:
    def __init__(self, Nombre):
        self.Nombre = Nombre


##########################################
#Bebida
##########################################

class Bebida:
    def __init__(self,Identificador, Nombre, Precio, Descripcion):
        self.Identificador = Identificador
        self.Nombre = Nombre
        self.Precio = Precio
        self.Descripcion = Descripcion

##########################################
#Desayuno
##########################################

class Desayuno:
    def __init__(self,Identificador, Nombre, Precio, Descripcion):
        self.Identificador = Identificador
        self.Nombre = Nombre
        self.Precio = Precio
        self.Descripcion = Descripcion

##########################################
#Postre
##########################################

class Postre:
    def __init__(self,Identificador, Nombre, Precio, Descripcion):
        self.Identificador = Identificador
        self.Nombre = Nombre
        self.Precio = Precio
        self.Descripcion = Descripcion

##########################################
# Errores
##########################################

class Error:
    def __init__(self, Fila, Columna, Caracter, Descripcion):
        self.Fila = Fila
        self.Columna = Columna
        self.Caracter = Caracter
        self.Descripcion = Descripcion

##########################################
# TOKENS
##########################################

class Token:
    def __init__(self, Lexema, Fila, Columna, Token):
        self.Lexema = Lexema
        self.Fila = Fila
        self.Columna = Columna
        self.Token = Token


#Resto Del Programa
################################

def CargarMenu():
    print("Cargar Menu: ")
    print('')
    global MenuAbierto
    MenuAbierto = ''
    filters = (("Archivos LFP", "*.lfp"), ("Todos los Archivos", "*.*"))
    MenuAbierto = tk.filedialog.askopenfilename(filetypes=filters)
    print(MenuAbierto)

    MenuAbiertoParaAbrir = open(MenuAbierto, "r", encoding='utf-8')
    MenuAbiertoReal = MenuAbiertoParaAbrir.read()
    ###########################################
    # ANALIZADOR LEXICO RESTAURANTE
    ###########################################
    # DefinirEstados
    # E0 = ParteInicialEtiqueta
    # E1 = EntreEtiquetas
    # E2 = ParteFinalEtiqueta

    Estado = 0
    CaracterActual = ""
    SiguienteCaracter = ""
    Lexema = ""
    ValorEtiqueta = ''
    TokenActual = ""
    Fila = 1
    Columna = 0
    ColumnaInicioToken = ''

    #########################################################################################
    # Variables Guardadas a Mostrar
    ##########################################################################################
    global ListaTokens
    global ListaErrores
    global ListaBebidas
    global ListaDesayunos
    global ListaPostres
    global ListaCaracteresEspecialesMenu

    ###############################################################
    # Variables que guarden el valor de las etiquetas de Productos
    ###############################################################

    IdentificadorActual = ''
    NombreActual = ''
    PrecioActual = ''
    global CuentaDePuntos
    DescripcionActual = ''

    ##############################################################
    # Variables que guarden el valor de las etiquetas de Seccion
    ##############################################################
    SeccionActual = ''

    #################################################################
    # Variables que guarden el valor de las etiquetas de Nombre Mapa
    #################################################################
    global NombreRestaurante

    for i in range(len(MenuAbiertoReal)):
        CaracterActual = MenuAbiertoReal[i]
        Columna = Columna + 1
        try:
            SiguienteCaracter = MenuAbiertoReal[i+1] #Este es un pequeño "Scout", puede ver valores que den error
        except:
            SiguienteCaracter = ""
        if (Estado == 0): #Busca R o r:
            if(CaracterActual == "R".lower()):
                if(SiguienteCaracter.isalpha()):
                    Lexema = Lexema + CaracterActual
                    print("Este es el Lexema: ", end='')
                    print(Lexema)
                    Estado = 1
                    ColumnaInicioToken = Columna
            elif (CaracterActual.isspace()):
                Estado = 0
                if (CaracterActual == "\n"):
                    Fila = Fila + 1
                    Columna = 0
            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))

        elif (Estado == 1): #PalabraDelToken
            if (CaracterActual.isalpha() and SiguienteCaracter != "="):
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)

            elif SiguienteCaracter == "=":
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)

                TokenActual = "Etiqueta Nombre Restaurante"
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaTokens.append(Token(Lexema, Fila, ColumnaInicioToken, TokenActual))
                #Volver a Vaciar el Lexema y el Token
                Lexema = ''
                TokenActual = ''

            elif (CaracterActual == "=" and SiguienteCaracter == "\'"):
                Estado = 2
                ColumnaInicioToken = Columna + 2
                print("Este es el Lexema: ", end='')
                print(Lexema)
            elif CaracterActual.isspace():
                Estado = 1

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))


        elif (Estado == 2): #Dentro de comillas NombreRestaurante
            if (CaracterActual=="\'" and SiguienteCaracter == "\n"):
                Estado = "Secciones 0"
                NombreRestaurante = Lexema
                print('EL nombre del resturante es: ' + NombreRestaurante)

                # Guardar Token en Lista de Tokens
                TokenActual = "Nombre Del Restaurante"
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaTokens.append(Token(Lexema, Fila, ColumnaInicioToken, TokenActual))
                Columna = 0
                Fila= Fila + 1

            else:
                if (CaracterActual == "\'"):
                    Lexema = ''

                elif CaracterActual in ListaCaracteresEspecialesMenu:
                    Lexema = Lexema + CaracterActual
                    print("Este es el Lexema: ", end='')
                    print(Lexema)

                else:
                    Lexema = Lexema + CaracterActual
                    print("Este es el Lexema: ", end='')
                    print(Lexema)

        elif (Estado == "Secciones 0"): #Etiquetas dentro de Restaurante

            if (CaracterActual == "\'"):#Encuantra el "'"
                ColumnaInicioToken = Columna
                Estado = "Secciones 1"
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)

                # Volver a Vaciar el Lexema y el Token
                Lexema = ''
                TokenActual = ''

            elif CaracterActual.isspace():
                Lexema = ''
                TokenActual = ''

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))

        elif (Estado == "Secciones 1"):#Dentro de Comillas

            if (CaracterActual.isalpha() and SiguienteCaracter != "\'"):
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))

            elif SiguienteCaracter == "\'":
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)

                # Guardar Token en Lista de Tokens
                TokenActual = "Nombre de Sección"
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaTokens.append(Token(Lexema, Fila, ColumnaInicioToken, TokenActual))

                #Cambio de Estado
                Estado = "Secciones 2"

            elif CaracterActual.isspace():
                Estado = "Secciones 1"


        elif (Estado == "Secciones 2"): #Busca la ' de cierre y los :

            if (CaracterActual == "\'"):
                #Agregar La Sección a la ListaSecciones:
                ListaSecciones.append(Seccion(Lexema))
                SeccionActual = Lexema

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))

            elif CaracterActual.isspace():
                Estado = "Secciones 2"

            elif (CaracterActual == ":" and SiguienteCaracter == "\n"):
                    Lexema = ''
                    TokenActual = ''
                    Columna = 0
                    Fila = Fila + 1

                    # Cambiar Estado
                    Estado = "Items 0"

        elif (Estado == "Items 0"): # Busca el [

            if (CaracterActual == "["):#Encuantra el "["
                ColumnaInicioToken = Columna
                Estado = "Items 1"
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)

                # Volver a Vaciar el Lexema y el Token
                Lexema = ''
                TokenActual = ''

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))

            elif CaracterActual.isspace():
                Estado = "Items 0"

        elif (Estado == "Items 1"): #IdentificadorItem

            if CaracterActual.isspace():
                Estado = "Items 1"

            elif CaracterActual != ";":
                if CaracterActual in ListaCaracteresEspecialesMenu:
                    TokenActual = "Caracter Invalido: " + CaracterActual
                    print("Este es el Token Actual: ", end='')
                    print(TokenActual)
                    ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))
                else:
                    Lexema = Lexema + CaracterActual
                    print("Este es el Lexema: ", end='')
                    print(Lexema)

            elif CaracterActual == ";":
                IdentificadorActual = Lexema
                # Guardar Token en Lista de Tokens
                TokenActual = "Identificador Item"
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaTokens.append(Token(Lexema, Fila, ColumnaInicioToken, TokenActual))

                #Cambiar Estado
                Estado = "Items 2.1"
                Lexema = ''
                TokenActual = ''


        elif (Estado == "Items 2.1"):  #Nombre Item, Comilla Inicial
            if (CaracterActual == "\'"):  # Encuantra el "'"
                ColumnaInicioToken = Columna + 1
                Estado = "Items 2.2"
                print("Este es el Lexema: ", end='')
                print(Lexema)
                # Volver a Vaciar el Lexema y el Token
                Lexema = ''
                TokenActual = ''

            elif CaracterActual.isspace():
                Estado = "Items 2.1"

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))


        elif (Estado == "Items 2.2"):  # Nombre Item, Nombre en sí
            if (CaracterActual.isalpha() and SiguienteCaracter != "\'"):
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)


            elif SiguienteCaracter == "\'":
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)
                # Guardar Token en Lista de Tokens
                TokenActual = "Nombre Item"
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaTokens.append(Token(Lexema, Fila, ColumnaInicioToken, TokenActual))

                # Cambio de Estado
                Estado = "Items 2.3"


            elif CaracterActual.isspace():
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)



        elif (Estado == "Items 2.3"):  #Nombre Item, Comilla Final

            if (CaracterActual == "\'"):
                NombreActual = Lexema

            elif CaracterActual.isspace():
                Estado = "Items 2.3"

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))

            elif (CaracterActual == ";"):
                Lexema = ''
                TokenActual = ''
                # Cambiar Estado
                Estado = "Items 3"

        elif (Estado == "Items 3"): #PrecioItem

            if CaracterActual.isspace():
                Estado = "Items 3"

            elif CaracterActual.isdigit() or CaracterActual == ".":
                ColumnaInicioToken = Columna
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)
                if CaracterActual == ".":
                    CuentaDePuntos = CuentaDePuntos + 1

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))

            elif SiguienteCaracter == ";":
                if not CaracterActual.isspace():
                    Lexema = Lexema + CaracterActual

            elif CaracterActual == ";":
                #Agregar los 00 si es necesario
                if CuentaDePuntos == 1 and Lexema[-1] == ".":
                    Lexema = Lexema + "00"

                    print("Este es el Lexema: ", end='')
                    print(Lexema)
                    PrecioActual = Lexema
                    # Guardar Token en Lista de Tokens
                    TokenActual = "Precio Item"
                    print("Este es el Token Actual: ", end='')
                    print(TokenActual)
                    ListaTokens.append(Token(Lexema, Fila, ColumnaInicioToken, TokenActual))

                    # Cambiar Estado
                    Estado = "Items 4.1"
                    Lexema = ''
                    TokenActual = ''
                    CuentaDePuntos = 0

                elif CuentaDePuntos == 1 and Lexema[-1].isdigit():
                    print("Este es el Lexema: ", end='')
                    print(Lexema)
                    PrecioActual = Lexema
                    # Guardar Token en Lista de Tokens
                    TokenActual = "Precio Item"
                    print("Este es el Token Actual: ", end='')
                    print(TokenActual)
                    ListaTokens.append(Token(Lexema, Fila, ColumnaInicioToken, TokenActual))

                    # Cambiar Estado
                    Estado = "Items 4.1"
                    Lexema = ''
                    TokenActual = ''
                    CuentaDePuntos = 0

                elif CuentaDePuntos == 0:
                    Lexema = Lexema + ".00"

                    print("Este es el Lexema: ", end='')
                    print(Lexema)
                    PrecioActual = Lexema
                    # Guardar Token en Lista de Tokens
                    TokenActual = "Precio Item"
                    print("Este es el Token Actual: ", end='')
                    print(TokenActual)
                    ListaTokens.append(Token(Lexema, Fila, ColumnaInicioToken, TokenActual))

                    # Cambiar Estado
                    Estado = "Items 4.1"
                    Lexema = ''
                    TokenActual = ''
                    CuentaDePuntos = 0


        elif (Estado == "Items 4.1"):  #Descripción Item, Comilla Inicial
            if (CaracterActual == "\'"):  # Encuantra el "'"
                ColumnaInicioToken = Columna + 1
                Estado = "Items 4.2"
                print("Este es el Lexema: ", end='')
                print(Lexema)
                # Volver a Vaciar el Lexema y el Token
                Lexema = ''
                TokenActual = ''

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))

            elif CaracterActual.isspace():
                Estado = "Items 4.1"


        elif (Estado == "Items 4.2"):  #Descripción Item en sí
            if (CaracterActual.isalpha() and SiguienteCaracter != "\'"):
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)

            elif SiguienteCaracter == "\'":
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)
                # Guardar Token en Lista de Tokens
                TokenActual = "Descripción Item"
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaTokens.append(Token(Lexema, Fila, ColumnaInicioToken, TokenActual))

                # Cambio de Estado
                Estado = "Items 4.3"

            elif CaracterActual.isspace():
                Lexema = Lexema + CaracterActual
                print("Este es el Lexema: ", end='')
                print(Lexema)

        elif (Estado == "Items 4.3"):  #Descripcion Item, Comilla Final
            if (CaracterActual == "\'"):
                DescripcionActual = Lexema
                Lexema = ''
                TokenActual = ''

                # Cambiar Estado
                Estado = "Items 5"

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))

            elif CaracterActual.isspace():
                Estado = "Items 4.3"


        elif (Estado == "Items 5"): #Buscar la etiqueta de cierre
            if CaracterActual == "\n" and SiguienteCaracter == "":

                # Vamos a definir nuevos estados para cada una de las 3 posibles "Etiquetas Padre"
                # Bebidas, Desayunos y Postres son los nombres de los estados.
                if SeccionActual.lower() == "bebidas":
                    ListaBebidas.append(Bebida(IdentificadorActual, NombreActual, PrecioActual, DescripcionActual))
                    Lexema = ''
                    TokenActual = ''

                elif SeccionActual.lower() == "desayunos":
                    ListaDesayunos.append(Desayuno(IdentificadorActual, NombreActual, PrecioActual, DescripcionActual))
                    Lexema = ''
                    TokenActual = ''

                elif SeccionActual.lower() == "postres":
                    ListaPostres.append(Postre(IdentificadorActual, NombreActual, PrecioActual, DescripcionActual))
                    Lexema = ''
                    TokenActual = ''

                Columna = 0
                print("Menu Cargado")
                MenuAbiertoParaAbrir.close()

            elif CaracterActual in ListaCaracteresEspecialesMenu:
                TokenActual = "Caracter Invalido: " + CaracterActual
                print("Este es el Token Actual: ", end='')
                print(TokenActual)
                ListaErrores.append(Error(Fila, Columna, CaracterActual, TokenActual))

            elif CaracterActual == "\n" and SiguienteCaracter == "[":
                Estado = "Items 0"
                Columna = 0
                Fila = Fila + 1

                # Vamos a definir nuevos estados para cada una de las 3 posibles "Etiquetas Padre"
                # Bebidas, Desayunos y Postres son los nombres de los estados.
                if SeccionActual.lower() == "bebidas":
                    ListaBebidas.append(Bebida(IdentificadorActual, NombreActual, PrecioActual, DescripcionActual))
                    Lexema = ''
                    TokenActual = ''

                elif SeccionActual.lower() == "desayunos":
                    ListaDesayunos.append(Desayuno(IdentificadorActual, NombreActual, PrecioActual, DescripcionActual))
                    Lexema = ''
                    TokenActual = ''

                elif SeccionActual.lower() == "postres":
                    ListaPostres.append(Postre(IdentificadorActual, NombreActual, PrecioActual, DescripcionActual))
                    Lexema = ''
                    TokenActual = ''

            elif CaracterActual == "\n" and SiguienteCaracter == "\n":
                Estado = "Secciones 0"
                Columna = 0
                Fila = Fila + 1
                # Vamos a definir nuevos estados para cada una de las 3 posibles "Etiquetas Padre"
                # Bebidas, Desayunos y Postres son los nombres de los estados.
                if SeccionActual.lower() == "bebidas":
                    ListaBebidas.append(Bebida(IdentificadorActual, NombreActual, PrecioActual, DescripcionActual))
                    Lexema = ''
                    TokenActual = ''

                elif SeccionActual.lower() == "desayunos":
                    ListaDesayunos.append(Desayuno(IdentificadorActual, NombreActual, PrecioActual, DescripcionActual))
                    Lexema = ''
                    TokenActual = ''

                elif SeccionActual.lower() == "postres":
                    ListaPostres.append(Postre(IdentificadorActual, NombreActual, PrecioActual, DescripcionActual))
                    Lexema = ''
                    TokenActual = ''

    #Generar el HTML
    print("")
    print("Generando Reporte en HTML...")

    #Inicio String HTML
    StringDocumentoHTML = '<!DOCTYPE html>\n<html>\n  <head>\n<style>\n table, th, td {\n border: 1px solid black;\n}\n</style>\n<title>Lista de Tokens</title>\n   </head>\n   <body>\n '
    # Titulo Archivo:
    StringDocumentoHTML = StringDocumentoHTML + '<h1>Lenguajes Formales y de Programación Proyecto 1</h1>\n<h2>Listas de Tokens: </h2>\n'
    # Crear Tabla Ordenar
    StringDocumentoHTML = StringDocumentoHTML + '<table>\n  <tr>\n  <th bgcolor = #E9967A>No.</th>\n\n <th bgcolor = #E9967A>Lexema</th>\n <th bgcolor = #E9967A>Fila</th>\n\n <th bgcolor = #E9967A>Columna</th>\n <th bgcolor = #E9967A>Token</th></tr>\n'

    for i in range(len(ListaTokens)) :
        StringDocumentoHTML = StringDocumentoHTML + '<tr style="background-color:#87CEFA">\n     <td>' + str(i+1) + "</td>\n  <td>"+str(ListaTokens[i].Lexema)+ '</td>\n <td>'+str(ListaTokens[i].Fila)+ '</td>\n <td>'+str(ListaTokens[i].Columna)+ '</td>\n <td>'+str(ListaTokens[i].Token)+ '</td>\n</tr>\n'

    # Generar el HTML
    with open("ListaTokens.html", "w") as ArchivoHTML:
        # Terminar el String del HTML
        StringDocumentoHTML = StringDocumentoHTML + '</table>\n</body>\n</html>'
        ArchivoHTML.write(StringDocumentoHTML)
        print('')
        print("Ahorita te lo abro ;v")
        webbrowser.open('ListaTokens.html')

    print('')
    input("Menu Cargado, ingrese cualquier valor para volver al Menú Principal: ")
    Menu()

def CargarOrden():
    print("Cargar Orden: ")
    print('')
    global OrdenAbierta
    # ListaOrdenadas.clear()
    # ListaBuscar.clear()
    # ListaTodas.clear()
    OrdenAbierta = ''
    filters = (("Archivos LFP", "*.lfp"), ("Todos los Archivos", "*.*"))
    OrdenAbierta = tk.filedialog.askopenfilename(filetypes=filters)
    root.destroy()
    print(OrdenAbierta)

    print('')
    input("Orden Cargada, ingrese cualquier valor para volver al Menú Principal: ")
    Menu()

def GenerarMenu():
    if MenuAbierto == '':
        input("No ha ingresado ningún archivo de menú, ingrese cualquier valor para volver al menú: ")
        Menu()
    elif not ListaErrores:
        print("No hay errores, Generando Menú...")
        OpcionFiltro = input("Desea ingresar un limite de precio? S/N: ")

        if OpcionFiltro.lower() == "s":
            DatoFiltro = input("Cual es el precio máximo que se va a mostrar? (Solo escriba el número): ")

            # Inicio String HTML
            StringDocumentoHTML = '<!DOCTYPE html>\n<html>\n  <head>\n <title>Menu Restaurante</title>\n</head>\n<body>\n'

            # Titulo Archivo
            StringDocumentoHTML = StringDocumentoHTML + '<h1><center>' + str(NombreRestaurante) + '</center></h1>'
            StringDocumentoHTML = StringDocumentoHTML + '<h2><center>Menú</center></h2>'

            for i in range(len(ListaSecciones)):
                StringDocumentoHTML = StringDocumentoHTML + '<h3>' + str(ListaSecciones[i].Nombre) + ': </h3>\n\n'
                if ListaSecciones[i].Nombre == "Bebidas":
                    for j in range(len(ListaBebidas)):
                        if ListaBebidas[j].Precio <= DatoFiltro:
                            StringDocumentoHTML = StringDocumentoHTML + '<h4>' + str(
                                ListaBebidas[j].Nombre) + ' Precio: Q.' + str(ListaBebidas[j].Precio) + '</h4>\n\n'
                            StringDocumentoHTML = StringDocumentoHTML + '<h5>' + str(
                                ListaBebidas[j].Descripcion) + '</h5>\n\n'
                            StringDocumentoHTML = StringDocumentoHTML + '<h2>---------------------------------------------------</h2>\n'

                elif ListaSecciones[i].Nombre == "Desayunos":
                    for j in range(len(ListaDesayunos)):
                        if ListaDesayunos[j].Precio <= DatoFiltro:
                            StringDocumentoHTML = StringDocumentoHTML + '<h4>' + str(
                                ListaDesayunos[j].Nombre) + ' Precio: Q.' + str(ListaDesayunos[j].Precio) + '</h4>\n\n'
                            StringDocumentoHTML = StringDocumentoHTML + '<h5>' + str(
                                ListaDesayunos[j].Descripcion) + '</h5>\n\n'
                            StringDocumentoHTML = StringDocumentoHTML + '<h2>---------------------------------------------------</h2>\n'

                elif ListaSecciones[i].Nombre == "Postres":
                    for j in range(len(ListaPostres)):
                        if ListaPostres[j].Precio <= DatoFiltro:
                            StringDocumentoHTML = StringDocumentoHTML + '<h4>' + str(
                                ListaPostres[j].Nombre) + ' Precio: Q.' + str(ListaPostres[j].Precio) + '</h4>\n\n'
                            StringDocumentoHTML = StringDocumentoHTML + '<h5>' + str(
                                ListaPostres[j].Descripcion) + '</h5>\n\n'
                            StringDocumentoHTML = StringDocumentoHTML + '<h2>---------------------------------------------------</h2>\n'

        elif OpcionFiltro.lower() == "n":
            #Inicio String HTML
            StringDocumentoHTML = '<!DOCTYPE html>\n<html>\n  <head>\n <title>Menu Restaurante</title>\n</head>\n<body>\n'

            #Titulo Archivo
            StringDocumentoHTML = StringDocumentoHTML + '<h1><center>' + str(NombreRestaurante) + '</center></h1>'
            StringDocumentoHTML = StringDocumentoHTML + '<h2><center>Menú</center></h2>'

            for i in range(len(ListaSecciones)):
                StringDocumentoHTML = StringDocumentoHTML + '<h3>' + str(ListaSecciones[i].Nombre) + ': </h3>\n\n'
                if ListaSecciones[i].Nombre == "Bebidas":
                    for j in range(len(ListaBebidas)):
                        StringDocumentoHTML = StringDocumentoHTML + '<h4>' + str(ListaBebidas[j].Nombre) + ' Precio: Q.' + str(ListaBebidas[j].Precio) + '</h4>\n\n'
                        StringDocumentoHTML = StringDocumentoHTML + '<h5>' + str(ListaBebidas[j].Descripcion) + '</h5>\n\n'
                        StringDocumentoHTML = StringDocumentoHTML + '<h2>---------------------------------------------------</h2>\n'

                elif ListaSecciones[i].Nombre == "Desayunos":
                    for j in range(len(ListaDesayunos)):
                        StringDocumentoHTML = StringDocumentoHTML + '<h4>' + str(ListaDesayunos[j].Nombre) + ' Precio: Q.' + str(ListaDesayunos[j].Precio) + '</h4>\n\n'
                        StringDocumentoHTML = StringDocumentoHTML + '<h5>' + str(ListaDesayunos[j].Descripcion) + '</h5>\n\n'
                        StringDocumentoHTML = StringDocumentoHTML + '<h2>---------------------------------------------------</h2>\n'

                elif ListaSecciones[i].Nombre == "Postres":
                    for j in range(len(ListaPostres)):
                        StringDocumentoHTML = StringDocumentoHTML + '<h4>' + str(ListaPostres[j].Nombre) + ' Precio: Q.' + str(ListaPostres[j].Precio) + '</h4>\n\n'
                        StringDocumentoHTML = StringDocumentoHTML + '<h5>' + str(ListaPostres[j].Descripcion) + '</h5>\n\n'
                        StringDocumentoHTML = StringDocumentoHTML + '<h2>---------------------------------------------------</h2>\n'
        else:
            print("")
            print("Caracter no valido, vuelva a intenarlo")
            input("Ingrese cualquier valor para volver al menú principal: ")
            Menu()

        # Generar el HTML
        with open("ListasEnHTML.html", "w") as ArchivoHTML:
            # Terminar el String del HTML
            StringDocumentoHTML = StringDocumentoHTML + '\n</body>\n</html>'
            ArchivoHTML.write(StringDocumentoHTML)
            print('')
            print("Ahorita te lo abro ;v")
            webbrowser.open('ListasEnHTML.html')


        print('')
        input("Menú Generado, ingrese cualquier valor para volver al Menú Principal: ")
        Menu()

    else:
        print("Si quiere ver un menú corrija primero los errores a continuación: ")

        # Inicio String HTML
        StringDocumentoHTML = '<!DOCTYPE html>\n<html>\n  <head>\n<style>\n table, th, td {\n border: 1px solid black;\n}\n</style>\n<title>Lista de Errores</title>\n   </head>\n   <body>\n '
        # Titulo Archivo:
        StringDocumentoHTML = StringDocumentoHTML + '<h1>Lenguajes Formales y de Programación Proyecto 1</h1>\n<h2>Lista de Errores: </h2>\n'
        # Crear Tabla Ordenar
        StringDocumentoHTML = StringDocumentoHTML + '<table>\n  <tr>\n  <th bgcolor = #E9967A>No.</th>\n\n <th bgcolor = #E9967A>Fila</th>\n <th bgcolor = #E9967A>Columna</th>\n\n <th bgcolor = #E9967A>Caracter</th>\n <th bgcolor = #E9967A>Descripción</th></tr>\n'

        for i in range(len(ListaErrores)):
            StringDocumentoHTML = StringDocumentoHTML + '<tr style="background-color:#87CEFA">\n     <td>' + str(i + 1) + "</td>\n  <td>" + str(ListaErrores[i].Fila) + '</td>\n <td>' + str(ListaErrores[i].Columna) + '</td>\n <td>' + str(ListaErrores[i].Caracter) + '</td>\n <td>' + str(ListaErrores[i].Descripcion) + '</td>\n</tr>\n'

        # Generar el HTML
        with open("ListaErrores.html", "w") as ArchivoHTML:
            # Terminar el String del HTML
            StringDocumentoHTML = StringDocumentoHTML + '</table>\n</body>\n</html>'
            ArchivoHTML.write(StringDocumentoHTML)
            print('')
            print("Ahorita te lo abro ;v")
            webbrowser.open('ListaErrores.html')

        print('')
        input("Lista de Errores generada, ingrese cualquier valor para volver al Menú Principal: ")
        Menu()


def GenerarFactura():
    print("GenerarFactura")

    print('')
    input("Ingrese cualquier valor para volver al Menú: ")
    Menu()

def GenerarArbol():
    print("Generar Arbol")
    if MenuAbierto == '':
        input("No ha ingresado ningún archivo de menú, ingrese cualquier valor para volver al menú: ")
        Menu()
    else:
        #Inicio del Codigo de GraohViz
        CodigoGraphViz = 'digraph D {\n rankdir = TB;\n A[label=\"' + NombreRestaurante + '\", style = filled, fillcolor = cyan];\n'
        NodosSecciones = ''

        #Ordenar Las Listas:
        #Lista Bebidas:
        for i in range(len(ListaBebidas)-1):
            for j in range(0, (len(ListaBebidas)-i)-1):
                if ListaBebidas[j].Precio > ListaBebidas[j+1].Precio:
                    ListaBebidas[j], ListaBebidas[j+1] = ListaBebidas[j+1], ListaBebidas[j]

        # Lista Desayunos:
        for i in range(len(ListaDesayunos) - 1):
            for j in range(0, (len(ListaDesayunos) - i) - 1):
                if ListaDesayunos[j].Precio > ListaDesayunos[j + 1].Precio:
                    ListaDesayunos[j], ListaDesayunos[j + 1] = ListaDesayunos[j + 1], ListaDesayunos[j]

        # Lista Postres:
        for i in range(len(ListaPostres) - 1):
            for j in range(0, (len(ListaPostres) - i) - 1):
                if ListaPostres[j].Precio > ListaPostres[j + 1].Precio:
                    ListaPostres[j], ListaPostres[j + 1] = ListaPostres[j + 1], ListaPostres[j]

        #Agregar Las Secciones
        for i in range(len(ListaSecciones)):

            #Agregar las opciones del menú:
            if ListaSecciones[i].Nombre == "Bebidas":
                NodosSecciones = str(ListaSecciones[i].Nombre) + '[label=\"' + str(ListaSecciones[i].Nombre) + '\", style = filled, fillcolor = chocolate];\n'
                CodigoGraphViz = CodigoGraphViz + NodosSecciones
                CodigoGraphViz = CodigoGraphViz + "A -> " + str(ListaSecciones[i].Nombre) + ';\n'

                for j in range(len(ListaBebidas)):
                    CodigoGraphViz = CodigoGraphViz + 'B' + str(j) +'[label=\"' + str(ListaBebidas[j].Nombre) + ' Precio: Q.' + str(ListaBebidas[j].Precio) + '\n ' + ListaBebidas[j].Descripcion +'\", style = filled, fillcolor = green];\n\n'
                    CodigoGraphViz = CodigoGraphViz + 'Bebidas -> B' + str(j) + ';\n'

            elif ListaSecciones[i].Nombre == "Desayunos":
                NodosSecciones = str(ListaSecciones[i].Nombre) + '[label=\"' + str(ListaSecciones[i].Nombre) + '\", style = filled, fillcolor = chocolate];\n'
                CodigoGraphViz = CodigoGraphViz + NodosSecciones
                CodigoGraphViz = CodigoGraphViz + "A -> " + str(ListaSecciones[i].Nombre) + ';\n'

                for j in range(len(ListaDesayunos)):
                    CodigoGraphViz = CodigoGraphViz + 'D' + str(j) + '[label=\"' + str(ListaDesayunos[j].Nombre) + ' Precio: Q.' + str(ListaDesayunos[j].Precio) + '\n ' + ListaDesayunos[j].Descripcion + '\", style = filled, fillcolor = lightpink];\n\n'
                    CodigoGraphViz = CodigoGraphViz + 'Desayunos -> D' + str(j) + ';\n'

            elif ListaSecciones[i].Nombre == "Postres":
                NodosSecciones = str(ListaSecciones[i].Nombre) + '[label=\"' + str(ListaSecciones[i].Nombre) + '\", style = filled, fillcolor = chocolate;]\n'
                CodigoGraphViz = CodigoGraphViz + NodosSecciones
                CodigoGraphViz = CodigoGraphViz + "A -> " + str(ListaSecciones[i].Nombre) + ';\n'

                for j in range(len(ListaPostres)):
                    CodigoGraphViz = CodigoGraphViz + 'P' + str(j) + '[label=\"' + str(ListaPostres[j].Nombre) + ' Precio: Q.' + str(ListaPostres[j].Precio) + '\n ' + ListaPostres[j].Descripcion + '\", style = filled, fillcolor = antiquewhite];\n\n'
                    CodigoGraphViz = CodigoGraphViz + 'Postres -> P' + str(j) + ';\n'

        # Generar El Archivo de GraphViz:
        with open("ElArbolDeLaVida.dot", 'w') as ArchivoGraphViz:

            # TerminarElStringDelCodigo
            CodigoGraphViz = CodigoGraphViz + "\n}"

            ArchivoGraphViz.write(CodigoGraphViz)
        ArchivoGraphViz.close()
        print('')
        print('Ahorita te lo abro ;v')
        os.system("dot -Tpdf ElArbolDeLaVida.dot -o ElFrutoDeEden.pdf")

        print('')
        input("Ingrese cualquier valor para volver al Menú: ")
        Menu()


def Menu():
    #Titulo
    print("             Proyecto 1 - LFP")
  #Caja Datos Alumno
    # Linea Superior
    for x in range(0, 42):
      print("-", end="")

    #Un Salto de Línea
    print()

    #Datos
    print("| Lenguajes Formales y de Programación   |")
    print("| Sección: B-                            |")
    print("| Nombre: Bryan Steve Montepeque Santos  |")
    print("| Carnet: 201700375                      |")

    # Linea Inferior
    for x in range(0, 42):
     print("-", end="")


  #Caja Opciones Menú

    #Un Salto de Linea
    print()

    #Partes Intermedias

    print("| 1. Cargar Menú                         |")
    print("| 2. Cargar Orden                        |")
    print("| 3. Generar Menú                        |")
    print("| 4. Generar Factura                     |")
    print("| 5. Generar Arbol                       |")
    print("| 6. Salir                               |")

    #Linea Inferior
    for x in range (0,42):
        print("-", end = "")

    # Un Salto de Linea
    print()


    #Texto e Input con Opciones y Try Except
    Valido = False
    while not Valido:
        try:
            OpcionMenu = int(input("Bienvenido, Ingrese el Número de la Operación que desee realizar: "))
            if OpcionMenu == 1:
                CargarMenu()
                Valido = True
            elif OpcionMenu == 2:
                CargarOrden()
                Valido = True
            elif OpcionMenu == 3:
                GenerarMenu()
                Valido = True
            elif OpcionMenu == 4:
                GenerarFactura()
                Valido = True
            elif OpcionMenu == 5:
                GenerarArbol()
                Valido = True
            elif OpcionMenu == 6:
                print("Entendible, Que tenga un Buen Día.jpg :)")
                print("")
                input("Ingrese cualquier valor para continuar: ")
                sys.exit()
            else:
                raise ValueError
        except ValueError:
            print(
                "Solo Puede Ingresar el Número de la función, por ejemplo, ingrese '1' si desea cargar un archivo, Intentelo de nuevo ")
        print()

#Iniciar el programa
Menu()