import time
import tkinter as tk
import sys
import csv
import os
import webbrowser

from tkinter import filedialog
#Crear Ventana Raiz para manejar mejor el Tkinter
root = tk.Tk()

##########################################
#Cosas Importantes
##########################################

#Variables Globales
##########################################
ArchivoAbierto = ''
ListaNombresGramaticas = []
ListaNoTerminales = []
ListaTerminales = []
ListaProducionesIniciales = []
ListaProducciones = []


def CargarArchivo():
    print("Cargar Archivo: ")
    print('')

    global ArchivoAbierto
    ArchivoAbierto = ''
    filters = (("Archivos GLC", "*.glc"), ("Todos los Archivos", "*.*"))
    ArchivoAbierto = tk.filedialog.askopenfilename(filetypes=filters)
    print(ArchivoAbierto)

    ArchivoAbiertoParaAbrir = open(ArchivoAbierto, "r", encoding='utf-8')
    ArchivoAbiertoReal = ArchivoAbiertoParaAbrir.read()
    print('')

    #########################################################################################
    # Variables Guardadas a Mostrar
    ##########################################################################################
    global ListaNombresGramaticas
    global ListaNoTerminales
    global ListaTerminales
    global ListaProducionesIniciales
    global ListaProducciones

    #########################################################################################
    # Vaciar Listas
    ##########################################################################################
    ListaNombresGramaticas = []
    ListaNoTerminales = []
    ListaTerminales = []
    ListaProducionesIniciales = []
    ListaProducciones = []

    with open(ArchivoAbierto, "r") as Archivo:
        #Obtener Cada Gramatica
        GramaticasPartidasEnAsterisco = ArchivoAbiertoReal.split("*")

        for Gramatica in range(0, len(GramaticasPartidasEnAsterisco)-1):
            #Inicializar Tipo de Gramatica para cada Gramatica
            TipoGramatica = ''

            #Obtener Cada Linea de cada Gramatica
            CadaGramaticaPartidaPorLineas = GramaticasPartidasEnAsterisco[Gramatica].split("\n")

            # ObtenerNombreGramatica
            if CadaGramaticaPartidaPorLineas[0] == "":
                NombreGramatica = CadaGramaticaPartidaPorLineas[1]
            else:
                NombreGramatica = CadaGramaticaPartidaPorLineas[0]

            print("Nombre Gramatica: " + NombreGramatica + " Reconocido")

            #Obtener NoTerminales, Terminales y Produccion Inicial
            if CadaGramaticaPartidaPorLineas[0] == "":
                ComponentesGramatica = CadaGramaticaPartidaPorLineas[2].split(";")
            else:
                ComponentesGramatica = CadaGramaticaPartidaPorLineas[1].split(";")

            #Partir los componentes en Terminales, No Terminales y Produccion Inicial

            NoTerminales = ComponentesGramatica[0]
            Terminales = ComponentesGramatica[1]
            ProduccionInicial = ComponentesGramatica[2]

            #Producciones de Gramatica
            ProduccionesGramatica = ''

            if CadaGramaticaPartidaPorLineas[0] == "":
                CantidadProduccionesTipo2 = 0
                for i in range(0, len(CadaGramaticaPartidaPorLineas) - 3):
                    # CrearVariables
                    CantidadNoTerminalesIzquierda = 0
                    CantidadNoTerminalesDerecha = 0
                    CantidadTerminalesDerecha = 0

                    ProduccionPartidaEnLaFlecha = CadaGramaticaPartidaPorLineas[i+3].split("->")

                    if CadaGramaticaPartidaPorLineas [i+3] == '':
                        x = 1
                    else:
                        # ObtenerNoTerminalesEnIzquierda
                        if ProduccionPartidaEnLaFlecha[0] in NoTerminales:
                            CantidadNoTerminalesIzquierda = CantidadNoTerminalesIzquierda + 1

                            # Partir Lado Derecho
                            ResultadoProduccionPartidoPorEspacios = ProduccionPartidaEnLaFlecha[1].split(" ")
                            if len(ResultadoProduccionPartidoPorEspacios) > 1:

                                for j in range(0, len(ResultadoProduccionPartidoPorEspacios)):
                                    if ResultadoProduccionPartidoPorEspacios[j] in NoTerminales:
                                        CantidadNoTerminalesDerecha = int(CantidadNoTerminalesDerecha) + 1
                                    elif ResultadoProduccionPartidoPorEspacios[j] in Terminales:
                                        CantidadTerminalesDerecha = int(CantidadTerminalesDerecha) + 1

                            elif len(ResultadoProduccionPartidoPorEspacios) == 1:
                                if ProduccionPartidaEnLaFlecha[1] in NoTerminales.split(","):
                                    CantidadNoTerminalesDerecha = int(CantidadNoTerminalesDerecha) + 1
                                elif ProduccionPartidaEnLaFlecha[1] in Terminales.split(","):
                                    CantidadTerminalesDerecha = int(CantidadTerminalesDerecha) + 1

                        if CantidadNoTerminalesIzquierda == 1:
                            if CantidadTerminalesDerecha > 1 or CantidadNoTerminalesDerecha > 1:
                                CantidadProduccionesTipo2 = int(CantidadProduccionesTipo2) + 1

                    ProduccionesGramatica = ProduccionesGramatica + str(CadaGramaticaPartidaPorLineas[i+2]) + "\n"

            else:
                CantidadProduccionesTipo2 = 0
                for i in range(0, len(CadaGramaticaPartidaPorLineas) - 3):

                    # CrearVariables
                    CantidadNoTerminalesIzquierda = 0
                    CantidadNoTerminalesDerecha = 0
                    CantidadTerminalesDerecha = 0

                    ProduccionPartidaEnLaFlecha = CadaGramaticaPartidaPorLineas[i+2].split("->")

                    if CadaGramaticaPartidaPorLineas [i+3] == '':
                        x = 1
                    else:
                        # ObtenerNoTerminalesEnIzquierda
                        if ProduccionPartidaEnLaFlecha[0] in NoTerminales:
                            CantidadNoTerminalesIzquierda = int(CantidadNoTerminalesIzquierda) + 1

                        #Partir Lado Derecho
                        ResultadoProduccionPartidoPorEspacios = ProduccionPartidaEnLaFlecha[1].split(" ")
                        if len(ResultadoProduccionPartidoPorEspacios) > 1:

                            for j in range(0, len(ResultadoProduccionPartidoPorEspacios)):
                                if ResultadoProduccionPartidoPorEspacios[j] in NoTerminales:
                                    CantidadNoTerminalesDerecha = int(CantidadNoTerminalesDerecha) + 1
                                elif ResultadoProduccionPartidoPorEspacios[j] in Terminales:
                                    CantidadTerminalesDerecha = int(CantidadTerminalesDerecha) + 1

                        elif len(ResultadoProduccionPartidoPorEspacios) == 1:
                            if ProduccionPartidaEnLaFlecha[1] in NoTerminales.split(","):
                                CantidadNoTerminalesDerecha = int(CantidadNoTerminalesDerecha) + 1
                            elif ProduccionPartidaEnLaFlecha[1] in Terminales.split(","):
                                CantidadTerminalesDerecha = int(CantidadTerminalesDerecha) + 1

                        if CantidadNoTerminalesIzquierda == 1:
                            if CantidadTerminalesDerecha > 1 or CantidadNoTerminalesDerecha > 1:
                                CantidadProduccionesTipo2 = int(CantidadProduccionesTipo2) + 1

                    ProduccionesGramatica = ProduccionesGramatica + str(CadaGramaticaPartidaPorLineas[i+2]) + "\n"


            print("Terminales: " + Terminales + " Reconocidos")
            print("No Temrinales: " + NoTerminales + " Reconocidos")
            print("Produccion Inicial: " + ProduccionInicial + " Reconocida")
            print("Producciones Reconocidas: ")
            print(ProduccionesGramatica)


            if CantidadProduccionesTipo2 > 0:
                TipoGramatica = "Tipo 2"
                print("Gramatica " + NombreGramatica + " Aceptada porque es Tipo 2, almacenando datos")

                #GuardarDatosEnListas
                ListaNombresGramaticas.append(NombreGramatica)
                print("Nombre Gramatica: " + NombreGramatica + " Almacenado")

                ListaTerminales.append(Terminales)
                print("Terminales: " + Terminales + " Almacenados")

                ListaNoTerminales.append(NoTerminales)
                print("No Temrinales: " + NoTerminales + " Almacenados")

                ListaProducionesIniciales.append(ProduccionInicial)
                print("Produccion Inicial: " + ProduccionInicial + " Almacenada")

                ListaProducciones.append(ProduccionesGramatica)
                print("Producciones Almacenadas")

                print("")
                print("Datos de " + NombreGramatica + " Almacenados")
            else:
                TipoGramatica = "No Tipo 2"
                print("Gramatica " + NombreGramatica + " Rechazada porque no es Tipo 2")

    print("Esto hay en la lista de Nombres: ")
    print(ListaNombresGramaticas)

    print('')
    input("Archivo Cargado, ingrese cualquier valor para volver al Menú Principal: ")
    Menu()

def InfoGramaticas():
    if ArchivoAbierto == '':
        input("No se ha cargado ningun archivo, ingrese un valor para volver al Menú Principal: ")
        Menu()
    else:
        #Mostrar Lista de Gramaticas Almacenadas
        print("Estas son las Gramaticas Almacenadas: ")
        for i in range(0, len(ListaNombresGramaticas)):
            print(str(i+1)+ ") " + ListaNombresGramaticas[i])

        Valido = False
        while not Valido:
            try:
                #Pide el nombre de la gramatica
                OpcionInfoGramticas = input("Ingrese el nombre de la gramatica de la cual quiere ver sus datos o escriba \'Menu\' para salir: ")

                #Es el nombre esta en la lista?
                NombreEnLista = False

                #Esta solo guarda el numero de la gramatica selecionada
                GramaticaSeleccionada = 0
                for i in range(0, len(ListaNombresGramaticas)):
                    if OpcionInfoGramticas == ListaNombresGramaticas[i]:
                        GramaticaSeleccionada = i
                        NombreEnLista = True
                        Valido = True

                if NombreEnLista == False:
                    if OpcionInfoGramticas.upper() == "MENU":
                        Valido = True
                        Menu()
                else:
                    raise ValueError
            except ValueError:
                print('')
            print("Ingresó un valor no valido, Intentelo de nuevo: ")
            print("")


        #Desplegar toda la info de las gramaticas
        print("Esta es la información de la Gramatica seleccionada: ")
        print("Nombre de la Gramatica Tipo 2: " + ListaNombresGramaticas[GramaticaSeleccionada])
        print("No Terminales: { " + ListaNoTerminales[GramaticaSeleccionada] + " }")
        print("Terminales: { " + ListaTerminales[GramaticaSeleccionada] + " }")
        print("Produccion Inicial: " + ListaProducionesIniciales[GramaticaSeleccionada])

        #Argupar Producciones segun su no terminal:

        #CrearElNuevoStringDeProducciones
        ProducionesOrdenadas = ''

        #IdentificarIndividualmenteLosNoTerminales
        NoTerminalesDeLaProduccion = ListaNoTerminales[GramaticaSeleccionada].split(",")

        #Recorrer la lista de No Terminales para verificar uno por todas las producciones
        for i in range(0, len(NoTerminalesDeLaProduccion)):
            ProducionesOrdenadas = ProducionesOrdenadas + NoTerminalesDeLaProduccion[i] + " -> "

            #Ver si es la primera produccion para escribirla normal
            PrimeraVezJPG = 0

            #Recorrer cada produccion
            for Produccion in ListaProducciones[GramaticaSeleccionada].split("\n"):
                ProducionPartidaEnFlecha = Produccion.split("->")

                if NoTerminalesDeLaProduccion[i] == ProducionPartidaEnFlecha[0]:
                    PrimeraVezJPG = PrimeraVezJPG + 1

                    if PrimeraVezJPG > 1:
                        # Escribir la produccion
                        ProducionesOrdenadas = ProducionesOrdenadas + "   |" + ProducionPartidaEnFlecha[1] + "\n"
                    elif PrimeraVezJPG == 1:
                        # Escribir la produccion
                        ProducionesOrdenadas = ProducionesOrdenadas + ProducionPartidaEnFlecha[1] + "\n"




        print("Producciones: \n" + ProducionesOrdenadas)


        print('')
        input("Informacion Mostrada, ingrese cualquier valor para volver al Menú de Gramaticas: ")
        InfoGramaticas()

def AutomataDePila():
    if ArchivoAbierto == '':
        input("No se ha cargado ningun archivo, ingrese un valor para volver al Menú Principal: ")
        Menu()
    else:
        # Mostrar Lista de Gramaticas Almacenadas
        print("Estas son las Gramaticas Almacenadas: ")
        for i in range(0, len(ListaNombresGramaticas)):
            print(str(i + 1) + ") " + ListaNombresGramaticas[i])

        Valido = False
        while not Valido:
            try:
                # Pide el nombre de la gramatica
                OpcionInfoGramticas = input("Ingrese el nombre de la gramatica de la cual quiere ver el Automata de Pila o escriba \'Menu\' para salir: ")

                # Es el nombre esta en la lista?
                NombreEnLista = False

                # Esta solo guarda el numero de la gramatica selecionada
                GramaticaSeleccionada = 0
                for i in range(0, len(ListaNombresGramaticas)):
                    if OpcionInfoGramticas == ListaNombresGramaticas[i]:
                        GramaticaSeleccionada = i
                        NombreEnLista = True
                        Valido = True

                if NombreEnLista == False:
                    if OpcionInfoGramticas.upper() == "MENU":
                        Valido = True
                        Menu()
                else:
                    raise ValueError
            except ValueError:
                print('')
            print("Ingresó un valor no valido, Intentelo de nuevo: ")
            print("")

        #Convertir la Gramática a un Automata de Pila
        AlfabetoAP = ListaTerminales[GramaticaSeleccionada]

        #JuntarSimbolosDePila
        SimbolosDePilaAP = ListaTerminales[GramaticaSeleccionada]
        SimbolosDePilaAP = SimbolosDePilaAP + ", " + ListaNoTerminales[GramaticaSeleccionada]
        SimbolosDePilaAP = SimbolosDePilaAP + ", #"

        #NombreAutomata
        NombreAP = "AP_" + ListaNombresGramaticas[GramaticaSeleccionada]

        #Simbolo Inicial de la Gramatica
        ProduccionesPartidasEnLineas = ListaProducciones[GramaticaSeleccionada].split("\n")
        PrimeraLineaPartidaEnFlecha = ProduccionesPartidasEnLineas[0].split("->")
        SimboloInicialAP = PrimeraLineaPartidaEnFlecha[0]


        #Inicio del Codigo de GraphViz y Datos Generales del AP
        CodigoGraphViz = 'digraph D {\n rankdir = LR;\n A[label=\" Nombre: ' + NombreAP + '\nAlfabeto Automata = { ' + AlfabetoAP + ' }\nSimbolos de Pila= { ' + SimbolosDePilaAP + ' }\nEstados = { i, p, q, f }\nEstado Inicial = { i }\nEstado Aceptación = { f }\", shape = none];\n'
        #Estructura Real de Automata De Pila
        #Estado i
        CodigoGraphViz = CodigoGraphViz + 'i[label=\"i\", shape = circle, style = filled, fillcolor = dodgerblue]\n'
        #Estado p
        CodigoGraphViz = CodigoGraphViz + 'p[label=\"p\", shape = circle, style = filled, fillcolor = green2]\n'
        #Estado q
        CodigoGraphViz = CodigoGraphViz + 'q[label=\"q\", shape = circle, style = filled, fillcolor = gold1]\n'
        #Estado f
        CodigoGraphViz = CodigoGraphViz + 'f[label=\"f\", shape = doublecircle, style = filled, fillcolor = crimson]\n'

        #Conexiones Iniciales
        CodigoGraphViz = CodigoGraphViz + 'i -> p [label=\"$, $; #\"]\np -> q[label=\"$, $; ' + SimboloInicialAP + '\"]\n'

        #Conexiones del Estado q de Arriba
        #Conexion q a q
        CodigoGraphViz = CodigoGraphViz + 'q -> q [label=\"'

        #Conexion por cada produccion
        if GramaticaSeleccionada == 0:
            #Conexiones del Estado q de Arriba
            for i in range(len(ProduccionesPartidasEnLineas) - 1):
                #PartirLineaDeProduccionEnFlecha
                LineasPartidasEnFlechas = ProduccionesPartidasEnLineas[i].split("->")
                CodigoGraphViz = CodigoGraphViz + '$, ' + LineasPartidasEnFlechas[0] + '; '+ LineasPartidasEnFlechas[1] + '\n'

            #Final Conexion cada Produccion
            CodigoGraphViz = CodigoGraphViz + '\"]\n'

            #Conexiones del Estado q de Abajo
            CodigoGraphViz = CodigoGraphViz + 'q:s -> q [dir=back, label=\"'
            CaracteresAlfabetoAP = AlfabetoAP.split(",")

            for i in range(len(CaracteresAlfabetoAP)):
                CodigoGraphViz = CodigoGraphViz + CaracteresAlfabetoAP[i] + ', ' + CaracteresAlfabetoAP[i] +'; $\n'

            # Final Conexion cada Caracter AlfabetoAP
            CodigoGraphViz = CodigoGraphViz + '\"]\n'

        else:
            #Conexiones del Estado q de Arriba
            for i in range(len(ProduccionesPartidasEnLineas) - 2):
                # PartirLineaDeProduccionEnFlecha
                LineasPartidasEnFlechas = ProduccionesPartidasEnLineas[i+1].split("->")
                CodigoGraphViz = CodigoGraphViz + '$, ' + LineasPartidasEnFlechas[0] + '; ' + LineasPartidasEnFlechas[
                    1] + '\n'

            # Final Conexion cada Produccion
            CodigoGraphViz = CodigoGraphViz + '\"]\n'

            # Conexiones del Estado q de Abajo
            CodigoGraphViz = CodigoGraphViz + 'q:s -> q [dir=back, label=\"'
            CaracteresAlfabetoAP = AlfabetoAP.split(",")

            for i in range(len(CaracteresAlfabetoAP)):
                CodigoGraphViz = CodigoGraphViz + CaracteresAlfabetoAP[i] + ', ' + CaracteresAlfabetoAP[i] + '; $\n'

            # Final Conexion cada Caracter AlfabetoAP
            CodigoGraphViz = CodigoGraphViz + '\"]\n'

        #Conexión Final
        CodigoGraphViz = CodigoGraphViz + 'q -> f[label=\"$, #; $\"]\n'


        # Generar El Archivo de GraphViz:
        with open("AP_GramTipo2.dot", 'w') as ArchivoGraphViz:

            # TerminarElStringDelCodigo
            CodigoGraphViz = CodigoGraphViz + "\n}"

            ArchivoGraphViz.write(CodigoGraphViz)

        ArchivoGraphViz.close()
        print('')
        print('Ahorita te lo abro ;v')
        os.system("dot -Tjpg AP_GramTipo2.dot -o AP_GramTipo2Real.jpg")
        webbrowser.open('AP_GramTipo2Real.jpg')

        print('')
        input("Automata Generado, ingrese cualquier valor para volver al Menú de Automatas: ")
        AutomataDePila()



def Menu():
    #Titulo
    print("             Proyecto 2 - LFP")
  #Caja Datos Alumno
    # Linea Superior
    for x in range(0, 42):
      print("-", end="")

    #Un Salto de Línea
    print()

    #Datos
    print("| Lenguajes Formales y de Programación   |")
    print("| Sección: B-                            |")
    print("| Nombre: Bryan Steve Montepeque Santos  |")
    print("| Carnet: 201700375                      |")

    # Linea Inferior
    for x in range(0, 42):
     print("-", end="")

    print("")

    #CuentaRegresiva
    Segundos = 5
    for i in range(Segundos):
        print("Tiempo Restante: " + str(Segundos))
        time.sleep(1)
        Segundos = Segundos - 1

        if Segundos == 0:
            print("Tiempo Restante: " + str(Segundos))
            print("Bienvenido!")


  #Caja Opciones Menú

    # Linea Superior
    for x in range(0, 42):
        print("-", end="")

    #Un Salto de Linea
    print()


    #Partes Intermedias

    print("| 1. Cargar Archivo                      |")
    print("| 2. Información General de Gramática    |")
    print("| 3. Generar Automata de Pila            |")
    print("| 4. Reporte de Recorrido                |")
    print("| 5. Reporte en Tabla                    |")
    print("| 6. Salir                               |")

    #Linea Inferior
    for x in range (0,42):
        print("-", end = "")

    # Un Salto de Linea
    print()


    #Texto e Input con Opciones y Try Except
    Valido = False
    while not Valido:
        try:
            OpcionMenu = int(input("Bienvenido, Ingrese el Número de la Operación que desee realizar: "))
            if OpcionMenu == 1:
                CargarArchivo()
                Valido = True
            elif OpcionMenu == 2:
                InfoGramaticas()
                Valido = True
            elif OpcionMenu == 3:
                AutomataDePila()
                Valido = True
            elif OpcionMenu == 4:
                print("Reporte de Recorrido")
                Valido = True
            elif OpcionMenu == 5:
                print("Tabla HTML")
                Valido = True
            elif OpcionMenu == 6:
                print("Entendible, Que tenga un Buen Día.jpg :)")
                print("")
                input("Ingrese cualquier valor para continuar: ")
                sys.exit()
            else:
                raise ValueError
        except ValueError:
            print(
                "Solo Puede Ingresar el Número de la función, por ejemplo, ingrese '1' si desea cargar un archivo, Intentelo de nuevo ")
        print()

#Iniciar el programa
Menu()